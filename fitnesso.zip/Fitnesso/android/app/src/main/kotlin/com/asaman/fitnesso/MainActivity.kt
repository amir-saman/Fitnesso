package com.asaman.fitnesso

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
